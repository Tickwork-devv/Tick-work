# tickwork-engine

A reference **CLMM engine** — concentrated-liquidity math in plain JavaScript,
zero dependencies, fully tested. The working core behind [tickwork](../).

## Install / run

No install needed — it's plain ES modules. To run the tests:

```bash
npm test        # node --test, 14 invariants
```

## Use it

```js
import { ClmmPool, ConstantProductPool } from "./src/index.js";

// concentrated liquidity pool at price 100, 0.30% fee
const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 30 });
const t = pool.tickCurrent;

// LP: deploy 1,000,000 liquidity within ~±10% of price
const { positionId, amountX, amountY } = pool.addLiquidity(t - 1000, t + 1000, 1_000_000);

// trader: buy X with 10,000 Y — walks across ticks
const { amountOut, ticksCrossed, unfilledIn } = pool.swapExactIn(10_000, "Y");

// LP: close, collect principal + earned fees
const { feesX, feesY } = pool.removeLiquidity(positionId);
```

## API

**`ConstantProductPool(reserveX, reserveY, feeBps = 30)`**
- `.price`, `.k`
- `.quote(amountIn, "X"|"Y")` → `{ amountOut, fee, priceImpact, execPrice, ... }`
- `.swap(amountIn, "X"|"Y")` → same shape, mutates reserves

**`ClmmPool({ initialPrice, tickSpacing = 10, feeBps = 30 })`**
- `.price`, `.tickCurrent`, `.liquidity`
- `.addLiquidity(tickLower, tickUpper, L)` → `{ positionId, amountX, amountY }`
- `.swapExactIn(amountIn, "X"|"Y")` → `{ amountOut, feePaid, unfilledIn, ticksCrossed, price }`
- `.removeLiquidity(positionId)` → `{ amountX, amountY, feesX, feesY }`

Helpers: `priceToTick`, `tickToPrice`, `amountXForLiquidity`, `amountYForLiquidity`.

## What the tests prove

Slippage grows with trade size · round trips lose exactly the fee · price↔tick
round-trips · in-range positions need both tokens, out-of-range need one ·
narrow ranges need >20x less capital for equal liquidity · swaps cross tick
boundaries and change active liquidity · a drained pool reports unfilled input ·
fees accrue to in-range LPs and split proportionally.

## Scope

Educational reference: floating point, unaudited, no oracle/protocol fee.
Not for production funds. MIT licensed.
