import test from "node:test";
import assert from "node:assert/strict";
import { ConstantProductPool } from "../src/amm.js";
import {
  ClmmPool, priceToTick, tickToPrice,
  amountXForLiquidity, amountYForLiquidity,
} from "../src/clmm.js";

const approx = (a, b, tol = 1e-6) =>
  assert.ok(Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)), `${a} !≈ ${b}`);

/* ---------------- constant product ---------------- */

test("x·y=k: k never decreases, and grows exactly by fees kept in the pool", () => {
  const pool = new ConstantProductPool(100, 10_000, 30);
  const k0 = pool.k;
  pool.swap(500, "Y");
  pool.swap(3, "X");
  assert.ok(pool.k > k0, "fees should grow k");
});

test("x·y=k: bigger trades get strictly worse average prices (slippage)", () => {
  const pool = new ConstantProductPool(100, 10_000, 0);
  const small = pool.quote(100, "Y");   // buy X with 100 Y
  const big = pool.quote(5_000, "Y");
  assert.ok(big.execPrice > small.execPrice, "big trade must pay a worse price");
  assert.ok(big.priceImpact > small.priceImpact);
});

test("x·y=k: round trip returns you less than you started with (the fee), never more", () => {
  const pool = new ConstantProductPool(100, 10_000, 30);
  const start = 1_000;
  const { amountOut: gotX } = pool.swap(start, "Y");
  const { amountOut: backY } = pool.swap(gotX, "X");
  assert.ok(backY < start, "no free money from swapping back and forth");
  assert.ok(backY > start * 0.98, "loss should be roughly the two fees, not more");
});

/* ---------------- tick math ---------------- */

test("ticks: price↔tick round-trips within one tick step", () => {
  for (const p of [0.0001, 0.5, 1, 42, 100, 98765]) {
    const t = priceToTick(p, 1);
    const back = tickToPrice(t);
    assert.ok(back <= p * 1.0000001, "tick price is floored");
    assert.ok(p / back < 1.0001 * 1.0000001, "within one 0.01% step");
  }
});

test("ticks: spacing alignment is enforced", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10 });
  assert.throws(() => pool.addLiquidity(5, 105, 1000), /not aligned/);
});

/* ---------------- positions & concentration ---------------- */

test("clmm: in-range position needs both tokens; out-of-range needs exactly one", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10 });
  const t = pool.tickCurrent;

  const inRange = pool.addLiquidity(t - 500, t + 500, 10_000);
  assert.ok(inRange.amountX > 0 && inRange.amountY > 0);

  const above = pool.addLiquidity(t + 1000, t + 2000, 10_000);
  assert.ok(above.amountX > 0 && above.amountY === 0, "range above price is all X");

  const below = pool.addLiquidity(t - 2000, t - 1000, 10_000);
  assert.ok(below.amountY > 0 && below.amountX === 0, "range below price is all Y");
});

test("clmm: concentration — same L costs far less capital in a narrow range", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10 });
  const t = pool.tickCurrent;
  const L = 50_000;
  const narrow = pool.addLiquidity(t - 100, t + 100, L);   // ≈ ±1%
  const wide = pool.addLiquidity(t - 10_000, t + 10_000, L); // ≈ ±63%
  const narrowCost = narrow.amountY + narrow.amountX * pool.price;
  const wideCost = wide.amountY + wide.amountX * pool.price;
  assert.ok(
    wideCost / narrowCost > 20,
    `wide range should need >20x the capital for equal L (got ${(wideCost / narrowCost).toFixed(1)}x)`
  );
});

test("clmm: deposit amounts match the closed-form liquidity formulas", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10 });
  const t = pool.tickCurrent;
  const L = 10_000;
  const { amountX, amountY } = pool.addLiquidity(t - 300, t + 300, L);
  const sa = Math.sqrt(tickToPrice(t - 300));
  const sb = Math.sqrt(tickToPrice(t + 300));
  approx(amountX, amountXForLiquidity(L, pool.sqrtP, sa, sb));
  approx(amountY, amountYForLiquidity(L, pool.sqrtP, sa, sb));
});

/* ---------------- swaps & crossing ---------------- */

test("clmm: a small swap inside one range matches constant-product behavior locally", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 0 });
  const t = pool.tickCurrent;
  pool.addLiquidity(t - 5000, t + 5000, 1_000_000);
  const p0 = pool.price;
  const { amountOut } = pool.swapExactIn(100, "Y"); // tiny vs liquidity
  assert.ok(amountOut > 0);
  assert.ok(pool.price > p0, "buying X must raise its price");
  // for a tiny trade, execution ≈ spot
  approx(100 / amountOut, p0, 1e-2);
});

test("clmm: swapping across a tick boundary crosses it and changes active liquidity", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 0 });
  const t = pool.tickCurrent;
  pool.addLiquidity(t - 200, t + 200, 100_000);        // core range
  pool.addLiquidity(t - 2000, t + 2000, 20_000);       // wider, thinner backup
  const before = pool.liquidity;
  const res = pool.swapExactIn(20_000, "Y");           // crosses +200, fills in the wide range
  assert.ok(res.ticksCrossed >= 1, "must cross at least one boundary");
  assert.ok(pool.liquidity < before, "leaving the core range sheds its liquidity");
  assert.equal(res.unfilledIn, 0);
});

test("clmm: price walking out of every range leaves a partial fill, not an infinite loop", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 0 });
  const t = pool.tickCurrent;
  pool.addLiquidity(t - 100, t + 100, 1_000);          // tiny pool only
  const res = pool.swapExactIn(10_000_000, "Y");
  assert.ok(res.unfilledIn > 0, "pool must run dry, not invent liquidity");
});

test("clmm: down-swaps mirror up-swaps (sell X, price falls)", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 0 });
  const t = pool.tickCurrent;
  pool.addLiquidity(t - 3000, t + 3000, 500_000);
  const p0 = pool.price;
  const res = pool.swapExactIn(1_000, "X");
  assert.ok(res.amountOut > 0);
  assert.ok(pool.price < p0, "selling X must lower its price");
});

/* ---------------- fees ---------------- */

test("clmm: fees accrue to in-range liquidity and are paid out on close", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 30 });
  const t = pool.tickCurrent;
  const { positionId } = pool.addLiquidity(t - 1000, t + 1000, 1_000_000);
  pool.swapExactIn(10_000, "Y");
  pool.swapExactIn(50, "X");
  const closed = pool.removeLiquidity(positionId);
  assert.ok(closed.feesY > 0, "Y-in swaps must pay Y fees to the LP");
  assert.ok(closed.feesX > 0, "X-in swaps must pay X fees to the LP");
  // fee magnitude sanity: 30bps of 10k ≈ 30 in Y
  assert.ok(closed.feesY > 25 && closed.feesY < 35);
});

test("clmm: two equal positions split fees equally", () => {
  const pool = new ClmmPool({ initialPrice: 100, tickSpacing: 10, feeBps: 30 });
  const t = pool.tickCurrent;
  const a = pool.addLiquidity(t - 1000, t + 1000, 500_000);
  const b = pool.addLiquidity(t - 1000, t + 1000, 500_000);
  pool.swapExactIn(20_000, "Y");
  const fa = pool.removeLiquidity(a.positionId);
  const fb = pool.removeLiquidity(b.positionId);
  approx(fa.feesY, fb.feesY, 1e-9);
});
