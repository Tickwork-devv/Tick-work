/**
 * Constant product AMM — the x·y=k pool.
 *
 * The entire market maker is one invariant: reserveX * reserveY = k.
 * Price is the ratio of reserves. Slippage is the curve steepening
 * as one side drains. Fees stay in the pool, so k grows over time —
 * that growth is what liquidity providers earn.
 */
export class ConstantProductPool {
  /**
   * @param {number} reserveX  initial reserve of token X
   * @param {number} reserveY  initial reserve of token Y
   * @param {number} feeBps    swap fee in basis points (30 = 0.30%)
   */
  constructor(reserveX, reserveY, feeBps = 30) {
    if (reserveX <= 0 || reserveY <= 0) throw new Error("reserves must be positive");
    this.x = reserveX;
    this.y = reserveY;
    this.feeBps = feeBps;
  }

  /** Spot price of X quoted in Y (how many Y one X is worth right now). */
  get price() {
    return this.y / this.x;
  }

  get k() {
    return this.x * this.y;
  }

  /**
   * Quote a swap without executing it.
   * @param {number} amountIn  amount of the input token
   * @param {"X"|"Y"} tokenIn  which token is being paid in
   */
  quote(amountIn, tokenIn) {
    if (amountIn <= 0) throw new Error("amountIn must be positive");
    const fee = amountIn * (this.feeBps / 10_000);
    const inNet = amountIn - fee;
    const [rIn, rOut] = tokenIn === "X" ? [this.x, this.y] : [this.y, this.x];
    // out = rOut - k / (rIn + inNet)
    const out = rOut - (rIn * rOut) / (rIn + inNet);
    const priceBefore = this.price;
    const nx = tokenIn === "X" ? this.x + amountIn : this.x - out;
    const ny = tokenIn === "X" ? this.y - out : this.y + amountIn;
    const priceAfter = ny / nx;
    return {
      amountOut: out,
      fee,
      priceBefore,
      priceAfter,
      /** signed price impact on X's price, as a fraction (0.05 = +5%) */
      priceImpact: priceAfter / priceBefore - 1,
      /** average execution price of X in Y for this trade */
      execPrice: tokenIn === "Y" ? amountIn / out : out / amountIn,
    };
  }

  /** Execute a swap, mutating reserves. Fee stays in the pool (accrues to LPs). */
  swap(amountIn, tokenIn) {
    const q = this.quote(amountIn, tokenIn);
    if (tokenIn === "X") {
      this.x += amountIn;
      this.y -= q.amountOut;
    } else {
      this.y += amountIn;
      this.x -= q.amountOut;
    }
    return q;
  }
}
