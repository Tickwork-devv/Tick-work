/**
 * CLMM engine — concentrated liquidity, for real.
 *
 * This is the same mathematical machine that runs Uniswap v3, Orca
 * Whirlpools, and Raydium CLMM, implemented in plain JavaScript:
 *
 *  - price space is discretized into TICKS: tick i ↔ price 1.0001^i
 *  - a POSITION is liquidity L deployed between two ticks
 *  - the pool tracks net liquidity change at each initialized tick
 *  - a SWAP walks the price across tick boundaries, consuming the
 *    liquidity that's active in each range
 *  - FEES accrue per unit of active liquidity (feeGrowthGlobal)
 *
 * Within a range, with sqrtP = √price and liquidity L:
 *    amountX held = L · (1/sqrtP − 1/sqrtPupper)
 *    amountY held = L · (sqrtP − sqrtPlower)
 * A swap of Y in moves sqrtP up by Δy/L; a swap of X in moves
 * 1/sqrtP up by Δx/L. Those four lines are the whole engine.
 *
 * Honest scope (this is a reference/educational engine):
 *  - floating point, not the Q64.96 fixed-point of production code
 *  - fee accounting uses global growth snapshots, exact for positions
 *    that stay in range for their lifetime (the common LP case)
 *  - no protocol fee, no oracle accumulator
 * Do not put real funds behind it. Do learn from it, test it, extend it.
 */

const TICK_BASE = 1.0001;

/** price → nearest usable tick index (floored to spacing) */
export function priceToTick(price, tickSpacing = 1) {
  if (price <= 0) throw new Error("price must be positive");
  const raw = Math.floor(Math.log(price) / Math.log(TICK_BASE));
  return Math.floor(raw / tickSpacing) * tickSpacing;
}

/** tick index → price */
export function tickToPrice(tick) {
  return Math.pow(TICK_BASE, tick);
}

/** Amount of X a position holds for liquidity L between sqrt prices (pa < pb). */
export function amountXForLiquidity(L, sqrtP, sqrtPa, sqrtPb) {
  const lo = Math.max(sqrtP, sqrtPa);
  if (lo >= sqrtPb) return 0; // price at/above range: no X held
  return L * (1 / lo - 1 / sqrtPb);
}

/** Amount of Y a position holds for liquidity L between sqrt prices (pa < pb). */
export function amountYForLiquidity(L, sqrtP, sqrtPa, sqrtPb) {
  const hi = Math.min(sqrtP, sqrtPb);
  if (hi <= sqrtPa) return 0; // price at/below range: no Y held
  return L * (hi - sqrtPa);
}

export class ClmmPool {
  /**
   * @param {object} opts
   * @param {number} opts.initialPrice  starting price of X in Y
   * @param {number} [opts.tickSpacing] tick grid coarseness (default 10 ≈ 0.10% steps)
   * @param {number} [opts.feeBps]      swap fee in basis points (default 30)
   */
  constructor({ initialPrice, tickSpacing = 10, feeBps = 30 }) {
    if (!(initialPrice > 0)) throw new Error("initialPrice must be positive");
    this.tickSpacing = tickSpacing;
    this.feeBps = feeBps;
    this.sqrtP = Math.sqrt(initialPrice);
    this.tickCurrent = priceToTick(initialPrice, tickSpacing);
    this.liquidity = 0; // active liquidity at current price
    /** @type {Map<number, {liquidityNet:number}>} initialized ticks */
    this.ticks = new Map();
    /** @type {Map<number, object>} open positions by id */
    this.positions = new Map();
    this._nextPositionId = 1;
    // fees owed per unit of liquidity, by token
    this.feeGrowthGlobalX = 0;
    this.feeGrowthGlobalY = 0;
  }

  get price() {
    return this.sqrtP * this.sqrtP;
  }

  _tickEntry(i) {
    if (!this.ticks.has(i)) this.ticks.set(i, { liquidityNet: 0 });
    return this.ticks.get(i);
  }

  _alignedTick(t) {
    if (t % this.tickSpacing !== 0) throw new Error(`tick ${t} not aligned to spacing ${this.tickSpacing}`);
    return t;
  }

  /**
   * Open a position: deploy liquidity L between tickLower and tickUpper.
   * Returns the token amounts the LP must deposit — note that a range
   * entirely above the current price needs only X, entirely below needs
   * only Y. That asymmetry is the "out of range" mechanic.
   */
  addLiquidity(tickLower, tickUpper, L) {
    this._alignedTick(tickLower);
    this._alignedTick(tickUpper);
    if (tickLower >= tickUpper) throw new Error("tickLower must be < tickUpper");
    if (!(L > 0)) throw new Error("L must be positive");

    const sqrtPa = Math.sqrt(tickToPrice(tickLower));
    const sqrtPb = Math.sqrt(tickToPrice(tickUpper));
    const amountX = amountXForLiquidity(L, this.sqrtP, sqrtPa, sqrtPb);
    const amountY = amountYForLiquidity(L, this.sqrtP, sqrtPa, sqrtPb);

    this._tickEntry(tickLower).liquidityNet += L; // crossing up: +L
    this._tickEntry(tickUpper).liquidityNet -= L; // crossing up past upper: −L
    if (this.tickCurrent >= tickLower && this.tickCurrent < tickUpper) {
      this.liquidity += L;
    }

    const id = this._nextPositionId++;
    this.positions.set(id, {
      id, tickLower, tickUpper, L,
      // fee snapshots: growth at open (exact accounting for stay-in-range positions)
      feeSnapshotX: this.feeGrowthGlobalX,
      feeSnapshotY: this.feeGrowthGlobalY,
    });
    return { positionId: id, amountX, amountY };
  }

  /** Close a position: withdraw its token amounts at current price + earned fees. */
  removeLiquidity(positionId) {
    const p = this.positions.get(positionId);
    if (!p) throw new Error("no such position");
    const sqrtPa = Math.sqrt(tickToPrice(p.tickLower));
    const sqrtPb = Math.sqrt(tickToPrice(p.tickUpper));
    const amountX = amountXForLiquidity(p.L, this.sqrtP, sqrtPa, sqrtPb);
    const amountY = amountYForLiquidity(p.L, this.sqrtP, sqrtPa, sqrtPb);
    const feesX = (this.feeGrowthGlobalX - p.feeSnapshotX) * p.L;
    const feesY = (this.feeGrowthGlobalY - p.feeSnapshotY) * p.L;

    this._tickEntry(p.tickLower).liquidityNet -= p.L;
    this._tickEntry(p.tickUpper).liquidityNet += p.L;
    if (this.tickCurrent >= p.tickLower && this.tickCurrent < p.tickUpper) {
      this.liquidity -= p.L;
    }
    this.positions.delete(positionId);
    return { amountX, amountY, feesX, feesY };
  }

  _initializedTicksSorted() {
    return [...this.ticks.keys()].sort((a, b) => a - b);
  }

  /** next initialized tick strictly above / at-or-below the current tick */
  _nextTickUp() {
    const t = this._initializedTicksSorted().find((i) => i > this.tickCurrent);
    return t === undefined ? null : t;
  }
  _nextTickDown() {
    const arr = this._initializedTicksSorted().filter((i) => i <= this.tickCurrent);
    return arr.length ? arr[arr.length - 1] : null;
  }

  /**
   * Swap with exact input, walking across ticks.
   * tokenIn "Y" pushes the price of X UP; tokenIn "X" pushes it DOWN.
   * Returns amounts plus the number of tick boundaries crossed, and any
   * unfilled input if the pool ran out of initialized liquidity.
   */
  swapExactIn(amountIn, tokenIn) {
    if (!(amountIn > 0)) throw new Error("amountIn must be positive");
    const feeRate = this.feeBps / 10_000;
    let remaining = amountIn;
    let amountOut = 0;
    let feePaid = 0;
    let ticksCrossed = 0;

    for (let guard = 0; guard < 10_000 && remaining > 1e-12; guard++) {
      if (this.liquidity <= 0) {
        // no active liquidity here: jump price to the next initialized tick, if any
        const next = tokenIn === "Y" ? this._nextTickUp() : this._nextTickDown();
        if (next === null) break; // nothing left anywhere: partial fill
        this.tickCurrent = next;
        this.sqrtP = Math.sqrt(tickToPrice(next));
        const entry = this.ticks.get(next);
        this.liquidity += tokenIn === "Y" ? entry.liquidityNet : -entry.liquidityNet;
        ticksCrossed++;
        continue;
      }

      const L = this.liquidity;
      const grossAvail = remaining;
      const netAvail = grossAvail * (1 - feeRate);

      if (tokenIn === "Y") {
        const boundary = this._nextTickUp();
        const sqrtTarget = boundary === null ? Infinity : Math.sqrt(tickToPrice(boundary));
        const yToBoundary = L * (sqrtTarget - this.sqrtP);
        if (netAvail < yToBoundary || boundary === null) {
          const newSqrtP = this.sqrtP + netAvail / L;
          amountOut += L * (1 / this.sqrtP - 1 / newSqrtP);
          this.sqrtP = newSqrtP;
          this.tickCurrent = priceToTick(this.price, this.tickSpacing);
          feePaid += grossAvail * feeRate;
          this.feeGrowthGlobalY += (grossAvail * feeRate) / L;
          remaining = 0;
        } else {
          amountOut += L * (1 / this.sqrtP - 1 / sqrtTarget);
          const grossUsed = yToBoundary / (1 - feeRate);
          feePaid += grossUsed * feeRate;
          this.feeGrowthGlobalY += (grossUsed * feeRate) / L;
          remaining -= grossUsed;
          this.sqrtP = sqrtTarget;
          this.tickCurrent = boundary;
          this.liquidity += this.ticks.get(boundary).liquidityNet;
          ticksCrossed++;
        }
      } else {
        const boundary = this._nextTickDown();
        // crossing DOWN happens at the boundary itself
        const sqrtTarget = boundary === null ? 0 : Math.sqrt(tickToPrice(boundary));
        // x in moves 1/sqrtP up: Δ(1/sqrtP) = Δx / L
        const xToBoundary = sqrtTarget === 0 ? Infinity : L * (1 / sqrtTarget - 1 / this.sqrtP);
        if (netAvail < xToBoundary || boundary === null) {
          const newInv = 1 / this.sqrtP + netAvail / L;
          const newSqrtP = 1 / newInv;
          amountOut += L * (this.sqrtP - newSqrtP);
          this.sqrtP = newSqrtP;
          this.tickCurrent = priceToTick(this.price, this.tickSpacing);
          feePaid += grossAvail * feeRate;
          this.feeGrowthGlobalX += (grossAvail * feeRate) / L;
          remaining = 0;
        } else {
          amountOut += L * (this.sqrtP - sqrtTarget);
          const grossUsed = xToBoundary / (1 - feeRate);
          feePaid += grossUsed * feeRate;
          this.feeGrowthGlobalX += (grossUsed * feeRate) / L;
          remaining -= grossUsed;
          this.sqrtP = sqrtTarget;
          this.tickCurrent = boundary - this.tickSpacing;
          this.liquidity -= this.ticks.get(boundary).liquidityNet;
          ticksCrossed++;
        }
      }
    }

    return { amountOut, feePaid, unfilledIn: remaining, ticksCrossed, price: this.price };
  }
}
