# tickwork

**Concentrated liquidity, as running code.**

An open-source, dependency-free implementation of the full CLMM (concentrated
liquidity market maker) machine — the math behind Uniswap v3, Orca Whirlpools,
and Raydium — paired with an interactive site that runs on it.

🔗 **Live site:** _(add your URL once GitHub Pages is set up)_

![tickwork](assets/banner.png)

---

## What's in here

```
tickwork/
├── index.html          # the interactive site (GitHub Pages serves this)
├── preview.png         # social share card
├── engine/             # tickwork-engine — the CLMM implementation
│   ├── src/            # amm.js, clmm.js, index.js
│   └── test/           # 14 invariant tests
└── assets/             # banner + profile art
```

## The engine

`engine/` is a standalone CLMM library with zero dependencies:

- **`ConstantProductPool`** — the `x·y=k` pool: quotes, swaps, slippage, fees
- **`ClmmPool`** — concentrated liquidity: tick math, ranged positions,
  cross-tick swaps that shed and gain liquidity as ranges activate, and fee
  accrual paid out on position close

Every claim it makes is a test you can run:

```bash
cd engine
npm test          # 14 invariants, all passing
```

The website isn't a description of the engine — it **embeds** it. Every figure
computes from the same functions, and section 07 executes the test suite in your
browser. Don't trust the page; run it.

## Run the site locally

It's a single static file — just open `index.html` in a browser, or serve it:

```bash
python3 -m http.server 8000    # then visit localhost:8000
```

## Honest scope

The engine is a **reference implementation for learning and prototyping**:
floating point (not production Q64.96 fixed-point), unaudited, no oracle or
protocol fee. Fee accounting is exact for positions that stay in range for their
lifetime. **Do not put real funds behind it.** Read it, test it, extend it.

## License

MIT — see [LICENSE](LICENSE). Use it, fork it, learn from it.
